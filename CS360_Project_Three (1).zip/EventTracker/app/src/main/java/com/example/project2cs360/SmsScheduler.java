package com.example.project2cs360;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import java.time.LocalDateTime;
import java.time.ZoneId;

/** Best-effort reminder scheduling using inexact alarms (no exact-alarm special access). */
public final class SmsScheduler {
    private SmsScheduler() { }

    private static PendingIntent pending(Context context, long id, String title, String phone, int flags) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("event_id", id);
        intent.putExtra("title", title);
        intent.putExtra("phone", phone);
        return PendingIntent.getBroadcast(context, (int) id, intent,
                flags | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void cancel(Context context, long id) {
        PendingIntent existing = pending(context, id, "", "", PendingIntent.FLAG_NO_CREATE);
        if (existing != null) {
            ((AlarmManager) context.getSystemService(Context.ALARM_SERVICE)).cancel(existing);
            existing.cancel();
        }
    }

    public static void schedule(Context context, long id, String title, String day,
                                String time, String phone) {
        cancel(context, id);
        if (context.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED
                || phone.isEmpty()) return;
        try {
            long at = LocalDateTime.parse(day + "T" + time)
                    .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
            if (at <= System.currentTimeMillis()) return;
            AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at,
                    pending(context, id, title, phone, PendingIntent.FLAG_UPDATE_CURRENT));
        } catch (RuntimeException ignored) {
            // Invalid dates must never crash the app or schedule a malformed alarm.
        }
    }

    public static void rescheduleAll(Context context) {
        try (Database db = new Database(context); Cursor c = db.allSmsEvents()) {
            while (c.moveToNext()) {
                schedule(context, c.getLong(0), c.getString(1), c.getString(2),
                        c.getString(3), c.getString(5));
            }
        }
    }
}
