package com.example.project2cs360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Local, per-account event storage. Passwords are salted and PBKDF2 hashed. */
public final class Database extends SQLiteOpenHelper {
    private static final String FILE = "event_tracker.db";
    public Database(Context context) { super(context, FILE, null, 3); }

    @Override public void onConfigure(SQLiteDatabase db) { db.setForeignKeyConstraintsEnabled(true); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL COLLATE NOCASE, salt TEXT NOT NULL, hash TEXT NOT NULL, " +
                "phone TEXT NOT NULL DEFAULT '', sms_enabled INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, title TEXT NOT NULL, day TEXT NOT NULL, " +
                "time TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', " +
                "category TEXT NOT NULL DEFAULT 'Life', favorite INTEGER NOT NULL DEFAULT 0, " +
                "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX idx_events_user_date ON events(user_id,day,time)");
    }

    /** Upgrades the starter project's existing database without deleting saved events. */
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE users ADD COLUMN phone TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE users ADD COLUMN sms_enabled INTEGER NOT NULL DEFAULT 0");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_events_user_date ON events(user_id,day,time)");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE events ADD COLUMN category TEXT NOT NULL DEFAULT 'Life'");
            db.execSQL("ALTER TABLE events ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0");
        }
    }

    private static String passwordHash(String password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 150000, 256);
        try {
            byte[] bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(bytes);
        } catch (Exception ex) { throw new IllegalStateException("Password hashing unavailable", ex); }
        finally { spec.clearPassword(); }
    }

    public boolean register(String username, String password) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("salt", Base64.getEncoder().encodeToString(salt));
        values.put("hash", passwordHash(password, salt));
        return getWritableDatabase().insert("users", null, values) != -1;
    }

    public long login(String username, String password) {
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id,salt,hash FROM users WHERE username=? COLLATE NOCASE",
                new String[]{username.trim()})) {
            if (!cursor.moveToFirst()) return -1;
            byte[] salt = Base64.getDecoder().decode(cursor.getString(1));
            byte[] expected = cursor.getString(2).getBytes(StandardCharsets.UTF_8);
            byte[] actual = passwordHash(password, salt).getBytes(StandardCharsets.UTF_8);
            return MessageDigest.isEqual(expected, actual) ? cursor.getLong(0) : -1;
        }
    }

    public long saveEvent(long userId, long eventId, String title, String day,
                          String time, String details) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("title", title);
        values.put("day", day);
        values.put("time", time);
        values.put("details", details);
        if (eventId < 0) return getWritableDatabase().insert("events", null, values);
        int changed = getWritableDatabase().update("events", values, "id=? AND user_id=?",
                new String[]{String.valueOf(eventId), String.valueOf(userId)});
        return changed > 0 ? eventId : -1;
    }

    public void setCategory(long userId, long eventId, String category) {
        ContentValues values = new ContentValues();
        values.put("category", category);
        getWritableDatabase().update("events", values, "id=? AND user_id=?",
                new String[]{String.valueOf(eventId), String.valueOf(userId)});
    }

    public void toggleFavorite(long userId, long eventId) {
        getWritableDatabase().execSQL("UPDATE events SET favorite=1-favorite WHERE id=? AND user_id=?",
                new Object[]{eventId, userId});
    }

    public boolean deleteEvent(long userId, long eventId) {
        return getWritableDatabase().delete("events", "id=? AND user_id=?",
                new String[]{String.valueOf(eventId), String.valueOf(userId)}) > 0;
    }

    public Cursor events(long userId) {
        return getReadableDatabase().rawQuery(
                "SELECT id,title,day,time,details,category,favorite FROM events WHERE user_id=? ORDER BY day,time,id",
                new String[]{String.valueOf(userId)});
    }

    public Cursor event(long userId, long eventId) {
        return getReadableDatabase().rawQuery(
                "SELECT id,title,day,time,details,category,favorite FROM events WHERE user_id=? AND id=?",
                new String[]{String.valueOf(userId), String.valueOf(eventId)});
    }

    public Cursor allSmsEvents() {
        return getReadableDatabase().rawQuery(
                "SELECT e.id,e.title,e.day,e.time,e.details,u.phone " +
                "FROM events e JOIN users u ON e.user_id=u.id " +
                "WHERE u.sms_enabled=1 AND length(u.phone)>0", null);
    }

    public String phone(long userId) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT phone FROM users WHERE id=?",
                new String[]{String.valueOf(userId)})) {
            return c.moveToFirst() ? c.getString(0) : "";
        }
    }

    public boolean smsEnabled(long userId) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT sms_enabled FROM users WHERE id=?",
                new String[]{String.valueOf(userId)})) {
            return c.moveToFirst() && c.getInt(0) == 1;
        }
    }

    public void updateSms(long userId, String phone, boolean enabled) {
        ContentValues values = new ContentValues();
        values.put("phone", phone);
        values.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update("users", values, "id=?",
                new String[]{String.valueOf(userId)});
    }
}
