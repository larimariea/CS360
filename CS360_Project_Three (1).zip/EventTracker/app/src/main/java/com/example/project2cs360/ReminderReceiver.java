package com.example.project2cs360;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;
import android.os.Build;

/** Sends a single opt-in SMS at the scheduled event time when permission still exists. */
public final class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (context.checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) return;
        long id = intent.getLongExtra("event_id", -1);
        if (id < 0) return;
        try (Database db = new Database(context)) {
            // Verify the event still exists, is opted in, and has not been deleted.
            try (android.database.Cursor c = db.getReadableDatabase().rawQuery(
                    "SELECT e.title,u.phone,e.day,e.time FROM events e " +
                    "JOIN users u ON e.user_id=u.id WHERE e.id=? AND u.sms_enabled=1",
                    new String[]{String.valueOf(id)})) {
                if (!c.moveToFirst() || c.getString(1).trim().isEmpty()) return;
                String title = c.getString(0);
                String phone = c.getString(1);
                String message = "EventTracker reminder: " + title + " at " + c.getString(3)
                        + " on " + c.getString(2) + ".";
                SmsManager sms;
                if (Build.VERSION.SDK_INT >= 31) {
                    sms = context.getSystemService(SmsManager.class);
                } else {
                    sms = SmsManager.getDefault();
                }
                if (sms != null) sms.sendTextMessage(phone, null, message, null, null);
            }
        } catch (Exception ignored) {
            // Devices without telephony, SIM service, or SMS access remain usable.
        }
    }
}
