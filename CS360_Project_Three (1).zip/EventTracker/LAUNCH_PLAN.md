# EventTracker — Launch and Sustainability Plan

## Product and intended audience
EventTracker is a lightweight personal event organizer for students, families, and people managing appointments. Its primary value is private, straightforward event tracking without creating an online account. The design prioritizes a readable list, minimal taps, and optional SMS reminders.

## Compatibility and release preparation
- Minimum Android version: Android 8.0 (API 26). Target/compile SDK: API 35. Java 17 and Android Gradle Plugin 8.7.3.
- Test on an API 26 emulator, a recent API 35 emulator, and at least one physical Android phone with a SIM. Verify portrait, small screens, and large accessibility font sizes.
- Run a clean Gradle sync, assembleDebug, lint, account/event regression tests, permission-denial tests, and real-device SMS tests before release. Archive logs/screenshots and a signed APK/AAB.
- Configure release signing securely, unique app ID, version codes, screenshots, store description, contact/support information, and a privacy policy. Never commit signing keys.

## Permissions, privacy, and security
- SEND_SMS is requested only when a user explicitly opts into SMS reminders. Declining does not block event tracking. The receiver checks permission again at send time.
- RECEIVE_BOOT_COMPLETED restores scheduled alarms after restart. No location, contacts, internet, or background tracking permissions are needed.
- The app stores usernames, salted PBKDF2 password hashes, events, phone numbers, and opt-in settings in local SQLite; Android backup is disabled. No information is sent to an analytics server.
- Users should be informed about carrier SMS fees, possible delays, and how to disable SMS. The launch version should add an explicit privacy notice, data deletion/export options, and formal accessibility testing.

## Monetization and market strategy
- Begin as a free academic prototype; do not monetize personal data or introduce ads on the login flow.
- Conduct interviews with students and appointment-heavy users, test onboarding completion and successful event creation, and prioritize improvements based on opt-in feedback.
- A future premium tier could offer optional cloud backup, shared calendars, recurring events, and cross-device sync; core event management remains free.
- Promotion: demonstration video, classroom presentation, app screenshots, and opt-in beta feedback. Measure retention and event-creation success, not intrusive tracking.

## SMS policy and go/no-go decision
Google Play restricts SMS permissions and generally reserves them for qualifying core use cases. **Do not assume this prototype qualifies for Play distribution.** Before public release, verify current Play policy, obtain required declarations/approval, or remove SEND_SMS and implement compliant local notifications or an opt-in server-side SMS service. Do not publish until the policy and privacy review are complete.

## Operational roadmap
1. **Prototype:** Validate login, SQLite CRUD, permission denial, event timing, and device reboot behavior.
2. **Private beta:** Collect crash reports voluntarily, test multiple Android versions, validate UI accessibility and event reliability.
3. **Release candidate:** Resolve bugs, document privacy, review SMS policy, produce signed build and store assets.
4. **Post-launch:** Provide support email, respond to bugs, patch dependencies, monitor Android compatibility, and plan backups and recurring events.
