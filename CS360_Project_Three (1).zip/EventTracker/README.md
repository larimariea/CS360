# Bloom Planner ✿ — CS 360 Project Three

An original Java/Android event planner with SQLite, account registration/login, an event grid, create/edit/delete, optional SMS reminders, a calendar, favorites, search, categories, and a countdown.

## Open
1. Open the **EventTracker** root folder in Android Studio (do not create a new project).
2. Sync Gradle and install the SDK requested by Android Studio.
3. Run on an emulator for planner features; use a real SIM-enabled phone to test SMS.
4. Run **Build > Make Project**, then **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Rubric map
- Log In: salted PBKDF2 account credentials in `Database.java`, UI in `MainActivity.java`.
- Database: SQLite, isolated users, migration to schema v3, add/edit/delete and 3-column `GridLayout`.
- SMS: optional consent, runtime permission, scheduler, receiver, reboot restoration.
- Coding: Java naming, focused database / alarm / receiver classes and inline comments.
- Launch: see `LAUNCH_PLAN.md`; test scenarios: `TEST_PLAN.md`.

## Limits
No APK is included because no Android SDK build was run in the authoring environment. The ZIP does not include Gradle wrapper binaries. SMS is subject to platform and Play Store policy limitations; do not assume exact delivery times.
