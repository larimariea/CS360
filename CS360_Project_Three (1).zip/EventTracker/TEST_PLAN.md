# EventTracker — Manual Verification Matrix

These are **tests to perform**, not claims that tests have passed. Record device, OS, outcome, and screenshot for each.

| ID | Test | Expected result |
|---|---|---|
| A1 | Register a new user with valid credentials | Account created; user can log in |
| A2 | Attempt duplicate username (case variation) | Duplicate rejected |
| A3 | Use short username or password | Validation message; no account created |
| A4 | Enter wrong password | Login rejected |
| D1 | Add two events in reverse date order | Grid/list sorted chronologically |
| D2 | Edit an event | Changes persist after app restart |
| D3 | Delete an event; cancel deletion once | Confirmation protects event; confirmed deletion removes it |
| D4 | Create events in two accounts | Each account sees only its own events |
| S1 | Decline SMS permission | Event CRUD continues; no SMS sent |
| S2 | Opt in with invalid phone number | Validation blocks save |
| S3 | Opt in on physical device with SIM and permission | Future event schedules SMS; verify delivery near event time |
| S4 | Disable SMS or delete event before due time | No corresponding SMS is sent |
| S5 | Reboot phone with an opted-in future event | Reminder is rescheduled after reboot |
| S6 | Revoke SMS permission in system settings | Receiver does not send SMS; app remains usable |
| P1 | Test API 26 and API 35 | App launches, login and CRUD work |
| P2 | Rotate device and increase font size | Note any UI issues for correction |

**Build commands:** Use Android Studio's Gradle tool window to run `:app:assembleDebug` and `:app:lint`. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

**Instructor demonstration:** Record a short screen capture of account creation, login, two events in date order, editing, deletion, permission denial, and continued event operation. SMS delivery requires a compatible real device and network.
