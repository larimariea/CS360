# Bloom Planner — Design and Feature Notes

Bloom is an original pastel lavender / rose event planner. Its purpose is to make scheduling feel encouraging rather than overwhelming. The app uses only native Android views and Java, so it needs no external UI libraries.

## Beyond the rubric
- A real three-column event grid (date, moment, time)
- Calendar date picking and tap-to-filter
- Search across titles, dates, and notes
- Five themed categories and category filters
- Favorite moments (persisted in SQLite)
- Upcoming-event countdown and live overview statistics
- Friendly empty states, confirmation dialogs, accessibility descriptions
- Local-first, account-isolated storage
- Pastel card-based UI with custom colors and clear visual hierarchy

## Important testing details
The calendar displays the current month by default; tapping a date fills the search filter. Tap Search / refresh to apply text changes. SMS reminders are sent at event time only when permission and user consent are enabled; alarms are inexact and SMS delivery depends on telephony. Google Play restricts SMS permissions; this is intended as an educational prototype.

## Build status
This project was generated and source-reviewed but not compiled in an Android SDK environment. Build and test on your machine before submitting.
